public enum BulletType
{
    Player,
    Enemy
}
