public enum RoomState // �ɼ�
{
    Unvisited,
    Discovered,
    Cleared
}
