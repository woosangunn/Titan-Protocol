public enum RoomType
{
    Start,
    Combat,
    Treasure,
    Shop,
    Boss
}