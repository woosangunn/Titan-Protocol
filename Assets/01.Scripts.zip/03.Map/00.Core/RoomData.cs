using UnityEngine;
using System.Collections.Generic;

public class RoomData
{
    public Vector2Int position;
    public RoomType type;
    public RoomState state = RoomState.Unvisited;

    public Vector2 size; // �� ���� ũ�� (Ÿ�� ����)
    public List<Vector2Int> neighborDirs = new();
}