using UnityEngine;
using UnityEngine.Tilemaps;

public class RoomTileRenderer : MonoBehaviour
{
    public Tilemap tilemap;
    public TileBase floorTile;
    public TileBase wallTile;

    public void DrawRoom(RoomData room, Vector3Int offset)
    {
        int width = (int)room.size.x;
        int height = (int)room.size.y;

        for (int x = 0; x < width; x++)
            for (int y = 0; y < height; y++)
            {
                bool isWall = x == 0 || y == 0 || x == width - 1 || y == height - 1;
                tilemap.SetTile(offset + new Vector3Int(x, y, 0), isWall ? wallTile : floorTile);
            }
    }

    public void ClearRoom(Vector3Int offset, Vector2 size)
    {
        for (int x = 0; x < (int)size.x; x++)
            for (int y = 0; y < (int)size.y; y++)
            {
                tilemap.SetTile(offset + new Vector3Int(x, y, 0), null);
            }
    }
}