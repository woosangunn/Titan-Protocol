using System.Collections.Generic;
using UnityEngine;

public class RoomManager : MonoBehaviour
{
    public static RoomManager Instance { get; private set; }

    public RoomGenerationMode generationMode = RoomGenerationMode.TilemapDraw;
    public int roomCount = 10;
    public Vector2Int tileOffsetStep = new Vector2Int(50, 40); // �� ���� ����

    private Dictionary<Vector2Int, RoomData> roomMap;
    private Vector2Int currentPos;

    private RoomTileRenderer tileRenderer;
    private Vector3Int lastRoomOffset;
    private Vector2 lastRoomSize;

    void Awake()
    {
        Instance = this;
        tileRenderer = GetComponent<RoomTileRenderer>();
    }

    void Start()
    {
        roomMap = new MapGenerator().GenerateMap(roomCount);
        currentPos = Vector2Int.zero;
        LoadRoom(currentPos);
    }

    public void TryMove(Vector2Int dir)
    {
        Vector2Int nextPos = currentPos + dir;
        if (!roomMap.ContainsKey(nextPos))
        {
            Debug.Log("�̵��� ���� ����");
            return;
        }

        LoadRoom(nextPos);
    }

    void LoadRoom(Vector2Int pos)
    {
        RoomData room = roomMap[pos];
        Vector3Int tileOffset = new Vector3Int(pos.x * tileOffsetStep.x, pos.y * tileOffsetStep.y, 0);

        if (tileRenderer != null)
        {
            tileRenderer.ClearRoom(lastRoomOffset, lastRoomSize);
            tileRenderer.DrawRoom(room, tileOffset);

            lastRoomOffset = tileOffset;
            lastRoomSize = room.size;
        }

        room.state = RoomState.Discovered;
        currentPos = pos;
    }

    public Vector2Int GetCurrentPosition() => currentPos;
}
